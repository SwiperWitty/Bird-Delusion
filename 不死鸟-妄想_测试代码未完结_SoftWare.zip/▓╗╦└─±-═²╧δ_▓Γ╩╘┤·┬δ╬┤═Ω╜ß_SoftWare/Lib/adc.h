#ifndef _ADC__H_
#define _ADC__H_

#define GPIO0 0
#define GPIO1 1

#define ADC_POWER 0x80 //ADC萇埭諷秶弇
#define ADC_FLAG 0x10  //ADC俇傖梓祩
#define ADC_START 0x08 //ADC宎諷秶弇

#define ADC_SPEEDLL 0x00 	//540跺奀笘
#define ADC_SPEEDL  0x20	//360跺奀笘
#define ADC_SPEEDH  0x40	//180跺奀笘
#define ADC_SPEEDHH 0x60 	//90跺奀笘

/*
		stc 15w 唳掛 2.0
*/

unsigned int GPIOX_ADCY(unsigned char Px, unsigned char ADCX,unsigned char Speed);

#endif