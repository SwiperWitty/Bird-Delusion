#ifndef __delay_H
#define __delay_H

void Delayx0us(unsigned char x); //@24.000MHz 
void Delayxms(unsigned char x);
void Delayx00ms(unsigned char x); //@24.000MHz

#endif