#include "uart.h"
#include "stc15.h"

//		stc15w没有定时器 1 			

/*
		stc 15w 版本 1.0	24.0 MHz
*/

unsigned char r_1,RXD_Flag = 0;
int Timer0;
xdata unsigned char array_r[20],array_s[20];
void UART_IRQ(void)			interrupt 4
{
	if(RI)
	{
		RI = 0;
		if(RXD_Flag == 0)
		{
			array_r[r_1++] = SBUF;
			if(SBUF == '}' || r_1 >= 20)
			{
				r_1 = 0;RXD_Flag = 1;
			}
		}
	}
}

void Baud_Rate (void)
{
	AUXR |= 0x04;		//定时器2时钟为Fosc,即1T
	T2L = 0x8F;			//设定定时初值
	T2H = 0xFD;			//设定定时初值
	AUXR |= 0x10;		//启动定时器2
}

void UartInit_1(void)	//24.0 MHz
{
	SCON = 0x50;		//8位数据,可变波特率
	AUXR |= 0x01;		//串口1选择定时器2为波特率发生器
	Baud_Rate ();
	ES = 1;
}

void UartInit_2(void)		//9600bps@24.000MHz
{
	S2CON = 0x50;		//8位数据,可变波特率
	Baud_Rate ();
}


void Timer0Init(void)		//100微秒@24.000MHz
{
	AUXR |= 0x80;		//定时器时钟1T模式
	TMOD &= 0xF0;		//设置定时器模式
	TL0 = 0xA5;		//设置定时初值
	TH0 = 0xF6;		//设置定时初值
	TF0 = 0;		//清除TF0标志
	TR0 = 1;		//定时器0开始计时
	ET0 = 1;
}

void Uart_Init(unsigned char x)
{
	switch (x)
	{
		case 1:
			Timer0Init();
			UartInit_1();
			Data_Replace (" ",array_r,0,sizeof(array_r));
			break;
		case 2:
			UartInit_2();
			break;
		default:
            break;
	}
}

void UARTX_Send(unsigned char Channels,char *Opinter,unsigned char Length)
{
	unsigned char num;
	if(Length > 30)	Length = 30;
	for (num = 0; num < Length; num++)
    {
        switch (Channels)
        {
        case 1:
            SBUF = *(Opinter+num);
            while (!TI)
                ;
            TI = 0;
            break;
        default:
            break;
        }
		if(*(Opinter+num) == '\0')	return;
    }
}
