#ifndef _UART__H_

#define _UART__H_

#define UART1 1
#define UART2 2

#include "Data_Handle.h"

/*
		stc 15w 1.0		24.0 MHz
*/

extern unsigned char r_1,RXD_Flag;
extern int Timer0;
extern xdata unsigned char array_r[20],array_s[20];


void Uart_Init(unsigned char x);
void Clean(unsigned char Length, unsigned char *Opinter);
void UARTX_Send(unsigned char Channels,char *Opinter,unsigned char Length);


#endif
