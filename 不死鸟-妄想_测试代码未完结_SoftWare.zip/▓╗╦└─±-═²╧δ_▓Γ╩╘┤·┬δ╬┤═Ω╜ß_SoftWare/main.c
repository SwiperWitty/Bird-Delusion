#include "STC15.H"
#include "oled.h"
#include "adc.h"
#include "stdio.h"
#include "Data_Handle.h"

#define LED_ON 0
#define LED_OF 1
#define Bzz_ON 0
#define Bzz_OF 1
#define KEY_ON 1
#define KEY_OF 0

#define ABat 2 									//0.02A 0.06V	2A 1V  	16.5w 0.42V
#define VBat 3 									// 3.3 * Multiple_V	= 18.645V
#define VTEM 4 									//2.2V  17 C

#define VDD 3.3
#define Multiple_V 7.65		
#define BatMIN 3.7
#define BatMAX 4.2
#define MAX_A 	8.00							//������,��λ (A)
#define MAX_T 	60								//����¶�,��λ (��)

sbit LED = P3 ^ 2;
sbit BZZ = P1 ^ 5;
sbit KEY = P5 ^ 5;

/*
		Delusion	80%
	VOL: 12.3V  TEMP: 23.4C
	ELE: 1.23A   MAX: 8.00A
 Producer: Cavendish
 
 
1.������⣺
	U = I *R;
	U = BatV / 20;
	I = BatV / 20 /0.02;
	
2.��ѹ��⣺
	adc = VCC * 1 / (1 + 6.8);
	VCC = adc * 7.8
	
3.�¶ȼ��

4.��ؼ��

*/

char xdata OLED_Array[20];
char ADC_Channle = VBat;
char Time_bat;
int Bat_Model;
float ADC_VOL;
struct
{
	unsigned int ADC_Temp;	//ADCԴ����
	unsigned int ADC_EleC;	//ADCԴ����
	unsigned int ADC_Bat;	//ADCԴ����
	float BatV;				//��ص�ѹ
	float Temp;
	float EleC;
}Voltage;

void UARTX_Send(unsigned char Channels,char *Opinter,unsigned char Length);
void Initialize (void);
void main (void)
{
	Initialize ();
	while(1) 
	{
		LED = !LED;
		ADC_VOL = GPIOX_ADCY(1,ABat,ADC_SPEEDH);
		ADC_VOL = (ADC_VOL / 1024) * VDD;
		Voltage.EleC = ADC_VOL * 2.5;	// (1 / 20 / 0.02)
		if(Voltage.EleC > MAX_A) KEY = 0;
		
		ADC_VOL = GPIOX_ADCY(1,VBat,ADC_SPEEDH);
		ADC_VOL = (ADC_VOL / 1024) * VDD;
		Voltage.BatV = ADC_VOL * Multiple_V;
		
		
		ADC_VOL = GPIOX_ADCY(1,VTEM,ADC_SPEEDH);
		ADC_VOL = (ADC_VOL / 1024) * VDD;
		Voltage.Temp = 56.5 / ADC_VOL;
		if(Voltage.Temp > MAX_T) KEY = 0;
		else if(Voltage.Temp > 40) BZZ = Bzz_ON;

		sprintf(OLED_Array,"%dS",Bat_Model);
		OLED_ShowString(01,0,OLED_Array,8);Data_Replace (" ",OLED_Array,'F',sizeof(OLED_Array));
		OLED_ShowString(06,0,"Delusion ",8);															// ����
		ADC_VOL =  (Voltage.BatV -  BatMIN * Bat_Model) / ((BatMAX - BatMIN) * Bat_Model) * 100;
		sprintf(OLED_Array,"%d%%",(int)ADC_VOL);
    	OLED_ShowString(17,0,OLED_Array,8);
		if(ADC_VOL < 2.0) KEY = KEY_OF;
		
		sprintf(OLED_Array,"VOL:%4.1fV ",Voltage.BatV);
		OLED_ShowString(0,1,OLED_Array,8);Data_Replace (" ",OLED_Array,'F',sizeof(OLED_Array));
		
		sprintf(OLED_Array,"TEM:%4.1fC",Voltage.Temp);
		OLED_ShowString(12,1,OLED_Array,8);Data_Replace (" ",OLED_Array,'F',sizeof(OLED_Array));
		
		sprintf(OLED_Array,"ELE:%.2fA   MAX:%.2fA",Voltage.EleC,MAX_A);
		OLED_ShowString(0,2,OLED_Array,8);Data_Replace (" ",OLED_Array,'F',sizeof(OLED_Array));
		
		OLED_ShowString(4,3,"Producer:Caven",8);
		Delayx00ms(1);
		//BZZ = !BZZ;
	}
}

void UartInit_1(void)	//24.0 MHz
{
	AUXR |= 0x04;		//��ʱ��2ʱ��ΪFosc,��1T
	T2L = 0x8F;			//�趨��ʱ��ֵ
	T2H = 0xFD;			//�趨��ʱ��ֵ
	AUXR |= 0x10;		//������ʱ��2
	SCON = 0x50;		//8λ����,�ɱ䲨����
	AUXR |= 0x01;		//����1ѡ��ʱ��2Ϊ�����ʷ�����
	ES = 1;
}

void Initialize (void)
{
	KEY = 1;
	BZZ = 1;
	
	OLED_Display_Off();
	OLED_Init();//��ʼ��OLED 
	UartInit_1();
	P1ASF = ~0XE3;								//ģ�⹦��A/Dʹ��
	P1M0 &= 0XE3;
	P1M1 |= ~0XE3;
	
	ADC_CONTR = (ADC_POWER | ADC_SPEEDL | ADC_Channle);
	ADC_CONTR |= ADC_START;
	
	ADC_VOL = GPIOX_ADCY(1,VBat,ADC_SPEEDH);
	ADC_VOL = (ADC_VOL / 1024) * VDD;
	Voltage.BatV = ADC_VOL * Multiple_V;
	Bat_Model = Voltage.BatV / BatMIN;
}

void UARTX_Send(unsigned char Channels,char *Opinter,unsigned char Length)
{
	unsigned char num;
	if(Length > 30)	Length = 30;
	for (num = 0; num < Length; num++)
    {
        switch (Channels)
        {
        case 1:
            SBUF = *(Opinter+num);
            while (!TI)
                ;
            TI = 0;
            break;
        default:
            break;
        }
		if(*(Opinter+num) == '\0')	return;
    }
}

